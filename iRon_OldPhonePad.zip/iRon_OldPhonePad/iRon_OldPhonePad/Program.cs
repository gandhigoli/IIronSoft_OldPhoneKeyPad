﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iRon_OldPhonePad
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string msg = string.Empty;
            Console.WriteLine("Enter the keypad input:");
            string input = Console.ReadLine(); // Read input from user

            string result = OldPhonePad(input, out msg); // Get the typed word
            if(string.IsNullOrWhiteSpace(msg))
            Console.WriteLine("Output: " + result); // Show the result
            else
                Console.WriteLine("Exception: " + msg);
        }


        // This method converts keypad input into a word like old mobile typing
        public static string OldPhonePad(string input, out string msg)
        {
            msg = string.Empty;
            var result = new StringBuilder();    // Stores final output text
            try
            {
                // If input is empty or null, return empty string
                if (string.IsNullOrEmpty(input)) return "";
                // This dictionary maps each number key to its corresponding letters
                var keypad = new Dictionary<char, string>
                {
                    { '1', "" }, { '2', "ABC" }, { '3', "DEF" },
                    { '4', "GHI" }, { '5', "JKL" }, { '6', "MNO" },
                    { '7', "PQRS" }, { '8', "TUV" }, { '9', "WXYZ" },
                    { '0', " " }
                };
                var current = new StringBuilder();   // Stores current pressed key group
                // Remove the ending '#' if present
                input = input.TrimEnd('#');
                // Loop through each character in input
                for (int i = 0; i < input.Length; i++)
                {
                    char ch = input[i];
                    // If '*' is pressed
                    if (ch == '*')
                    {
                        if (current.Length > 0)
                            current.Clear();        // Cancel current group
                        else if (result.Length > 0)
                            result.Length--;       // Delete last added letter
                    }
                    // If space is pressed, it means user finished a group
                    else if (ch == ' ')
                    {
                        ProcessGroup(current, result, keypad,out msg);  // Process the current group
                    }
                    else
                    {
                        // If different key is pressed, process the previous group
                        if (current.Length > 0 && current[0] != ch)
                        {
                            ProcessGroup(current, result, keypad, out msg);
                        }
                        current.Append(ch); // Add current digit to the group
                    }
                }
                // Process the remaining group at the end
                ProcessGroup(current, result, keypad, out msg);
            }
            catch (Exception ex)
            {
                msg = "Function Name: OldPhonePad()\nCatch Block Exception: " + ex.Message + "\nException Source: " + ex.Source;
            }
            // Return the final result
            return result.ToString();
        }


        // This method converts a group of same digits into the correct letter
        private static void ProcessGroup(StringBuilder group, StringBuilder result, Dictionary<char, string> keypad,out string msg)
        {
           msg = string.Empty;
            try
            {
                if (group.Length == 0) return;

                char key = group[0];            // The number key pressed
                int pressCount = group.Length;  // How many times it was pressed

                // Get the letters for that key and pick correct one based on press count
                if (keypad.TryGetValue(key, out string letters) && letters.Length > 0)
                {
                    char letter = letters[(pressCount - 1) % letters.Length];
                    result.Append(letter); // Add selected letter to result
                }
            }
            catch (Exception ex)
            {
                msg = "Function Name: ProcessGroup()\nCatch Block Exception: " + ex.Message + "\nException Source: " + ex.Source;
            }
            group.Clear(); // Clear group for next use
        }
    }
}
